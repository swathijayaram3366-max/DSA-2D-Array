// LeetCode 1672 - Richest Customer Wealth
class Solution {
    public int maximumWealth(int[][] accounts) {
        int max = 0;
        for (int[] account : accounts) {
            int sum = 0;
            for (int val : account) {
                sum += val;
            }
            max = Math.max(max, sum);
        }
        return max;
    }
}
